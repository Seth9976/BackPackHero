﻿using System;
using System.Collections.Generic;

// Token: 0x0200017C RID: 380
// (Invoke) Token: 0x06000F46 RID: 3910
public delegate void OnPollEndDelegate(List<PollOption> ranking, bool noVotes, bool draw);
