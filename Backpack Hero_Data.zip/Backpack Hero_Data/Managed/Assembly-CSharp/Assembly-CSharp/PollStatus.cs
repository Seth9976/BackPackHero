﻿using System;

// Token: 0x0200017A RID: 378
public enum PollStatus
{
	// Token: 0x04000C61 RID: 3169
	NotInitialized,
	// Token: 0x04000C62 RID: 3170
	NotStarted,
	// Token: 0x04000C63 RID: 3171
	Running,
	// Token: 0x04000C64 RID: 3172
	Ended,
	// Token: 0x04000C65 RID: 3173
	ResultProcessed,
	// Token: 0x04000C66 RID: 3174
	Fulfilled
}
