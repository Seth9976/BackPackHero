﻿using System;

// Token: 0x0200017D RID: 381
// (Invoke) Token: 0x06000F4A RID: 3914
public delegate void OnVotedDelegate(Chatter voter, int number);
