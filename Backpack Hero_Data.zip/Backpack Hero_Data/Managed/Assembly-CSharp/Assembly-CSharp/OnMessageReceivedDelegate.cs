﻿using System;
using TwitchLib.Client.Events;

// Token: 0x02000173 RID: 371
// (Invoke) Token: 0x06000F01 RID: 3841
public delegate void OnMessageReceivedDelegate(object sender, OnMessageReceivedArgs e);
