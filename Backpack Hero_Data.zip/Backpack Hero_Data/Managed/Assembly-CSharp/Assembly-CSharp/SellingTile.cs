﻿using System;
using UnityEngine;

// Token: 0x02000194 RID: 404
public class SellingTile : MonoBehaviour
{
	// Token: 0x04000D4F RID: 3407
	[SerializeField]
	public RuleTile tileToSpawn;
}
