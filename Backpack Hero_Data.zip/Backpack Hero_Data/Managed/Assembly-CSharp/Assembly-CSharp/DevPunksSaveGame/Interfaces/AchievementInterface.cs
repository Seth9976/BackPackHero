﻿using System;

namespace DevPunksSaveGame.Interfaces
{
	// Token: 0x02000231 RID: 561
	public interface AchievementInterface
	{
		// Token: 0x06001274 RID: 4724
		void UnlockAchievement(AchievementIds ids, int value = 0);
	}
}
