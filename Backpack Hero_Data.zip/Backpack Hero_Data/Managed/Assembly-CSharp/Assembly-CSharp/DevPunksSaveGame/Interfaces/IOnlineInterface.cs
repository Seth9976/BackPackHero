﻿using System;

namespace DevPunksSaveGame.Interfaces
{
	// Token: 0x02000235 RID: 565
	public interface IOnlineInterface
	{
	}
}
