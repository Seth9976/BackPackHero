﻿using System;

namespace DevPunksSaveGame.Interfaces
{
	// Token: 0x02000232 RID: 562
	public enum EFileResult
	{
		// Token: 0x04000E7F RID: 3711
		Ok,
		// Token: 0x04000E80 RID: 3712
		NoSpace,
		// Token: 0x04000E81 RID: 3713
		Broken,
		// Token: 0x04000E82 RID: 3714
		Other
	}
}
