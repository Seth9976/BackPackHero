﻿using System;

namespace DevPunksSaveGame
{
	// Token: 0x02000230 RID: 560
	public struct AchievementIds
	{
		// Token: 0x04000E78 RID: 3704
		public string SteamId;

		// Token: 0x04000E79 RID: 3705
		public string XboxId;

		// Token: 0x04000E7A RID: 3706
		public int PS4Id;

		// Token: 0x04000E7B RID: 3707
		public int PS5Id;

		// Token: 0x04000E7C RID: 3708
		public int Steam;

		// Token: 0x04000E7D RID: 3709
		public uint UnlockCount;
	}
}
