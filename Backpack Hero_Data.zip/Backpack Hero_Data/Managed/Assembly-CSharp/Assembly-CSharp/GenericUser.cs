﻿using System;

// Token: 0x02000023 RID: 35
public class GenericUser
{
	// Token: 0x04000086 RID: 134
	public string Id;

	// Token: 0x04000087 RID: 135
	public string Tag;
}
