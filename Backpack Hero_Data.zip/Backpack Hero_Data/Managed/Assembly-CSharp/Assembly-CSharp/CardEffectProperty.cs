﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x020000A6 RID: 166
public class CardEffectProperty : MonoBehaviour
{
	// Token: 0x060003DC RID: 988 RVA: 0x000272F9 File Offset: 0x000254F9
	private void Start()
	{
	}

	// Token: 0x060003DD RID: 989 RVA: 0x000272FB File Offset: 0x000254FB
	private void Update()
	{
	}

	// Token: 0x040002CE RID: 718
	public TextMeshProUGUI triggerText;

	// Token: 0x040002CF RID: 719
	public GameObject cardPropertyPrefab;
}
