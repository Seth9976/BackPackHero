﻿using System;
using UnityEngine;

// Token: 0x02000085 RID: 133
public class PetEffect : MonoBehaviour
{
	// Token: 0x040001EC RID: 492
	public Enemy.PossibleAttack possibleAttack;
}
