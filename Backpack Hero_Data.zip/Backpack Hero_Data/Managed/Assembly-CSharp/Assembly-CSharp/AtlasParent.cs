﻿using System;
using UnityEngine;

// Token: 0x02000181 RID: 385
public class AtlasParent : MonoBehaviour
{
	// Token: 0x06000F7C RID: 3964 RVA: 0x0009724C File Offset: 0x0009544C
	private void Start()
	{
	}

	// Token: 0x06000F7D RID: 3965 RVA: 0x0009724E File Offset: 0x0009544E
	private void Update()
	{
	}
}
