﻿using System;
using UnityEngine;

// Token: 0x020000C7 RID: 199
public class DungeonEventSpecial : MonoBehaviour
{
	// Token: 0x060005BE RID: 1470 RVA: 0x0003860A File Offset: 0x0003680A
	public virtual void Play()
	{
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x0003860C File Offset: 0x0003680C
	public virtual void SpecialEffect()
	{
	}
}
