﻿using System;
using UnityEngine;

// Token: 0x0200014A RID: 330
[Serializable]
public class Overworld_Item
{
	// Token: 0x04000A46 RID: 2630
	public string name;

	// Token: 0x04000A47 RID: 2631
	public Sprite sprite;
}
