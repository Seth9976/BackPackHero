﻿using System;

// Token: 0x0200008B RID: 139
public enum Platform
{
	// Token: 0x0400020C RID: 524
	PC,
	// Token: 0x0400020D RID: 525
	Editor,
	// Token: 0x0400020E RID: 526
	NintendoSwitch,
	// Token: 0x0400020F RID: 527
	XBox,
	// Token: 0x04000210 RID: 528
	XBoxOne,
	// Token: 0x04000211 RID: 529
	XBoxSeriesX,
	// Token: 0x04000212 RID: 530
	XboxSeriesS,
	// Token: 0x04000213 RID: 531
	PlayStation,
	// Token: 0x04000214 RID: 532
	PlayStation4,
	// Token: 0x04000215 RID: 533
	PlayStation5,
	// Token: 0x04000216 RID: 534
	DevelopmentBuild
}
