﻿using System;

// Token: 0x02000130 RID: 304
public enum LogLevel
{
	// Token: 0x04000954 RID: 2388
	Debug,
	// Token: 0x04000955 RID: 2389
	Warning,
	// Token: 0x04000956 RID: 2390
	Error
}
