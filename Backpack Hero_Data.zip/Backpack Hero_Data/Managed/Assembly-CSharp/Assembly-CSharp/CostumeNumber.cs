﻿using System;
using UnityEngine;

// Token: 0x0200001C RID: 28
public class CostumeNumber : MonoBehaviour
{
	// Token: 0x060000C5 RID: 197 RVA: 0x00006ADD File Offset: 0x00004CDD
	private void Start()
	{
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00006ADF File Offset: 0x00004CDF
	private void Update()
	{
	}
}
