﻿using System;

// Token: 0x02000090 RID: 144
public class PrebuilderInterface
{
}
