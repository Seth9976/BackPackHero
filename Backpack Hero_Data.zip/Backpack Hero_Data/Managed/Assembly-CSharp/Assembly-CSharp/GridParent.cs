﻿using System;
using UnityEngine;

// Token: 0x020000D8 RID: 216
public class GridParent : MonoBehaviour
{
	// Token: 0x0600064B RID: 1611 RVA: 0x0003DB30 File Offset: 0x0003BD30
	private void Start()
	{
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x0003DB32 File Offset: 0x0003BD32
	private void Update()
	{
	}
}
