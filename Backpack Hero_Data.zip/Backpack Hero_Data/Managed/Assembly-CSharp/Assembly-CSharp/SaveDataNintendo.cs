﻿using System;
using UnityEngine;

// Token: 0x02000167 RID: 359
public class SaveDataNintendo : MonoBehaviour
{
}
