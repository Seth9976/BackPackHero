﻿using System;
using UnityEngine;

// Token: 0x0200006F RID: 111
public class LoreUnlocker : MonoBehaviour
{
	// Token: 0x04000173 RID: 371
	[SerializeField]
	public string loreNameKey;
}
