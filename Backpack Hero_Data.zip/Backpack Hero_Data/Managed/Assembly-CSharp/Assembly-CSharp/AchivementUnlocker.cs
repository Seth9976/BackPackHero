﻿using System;
using UnityEngine;

// Token: 0x02000003 RID: 3
public class AchivementUnlocker : MonoBehaviour
{
	// Token: 0x0600000B RID: 11 RVA: 0x0000271B File Offset: 0x0000091B
	private void Start()
	{
	}

	// Token: 0x0600000C RID: 12 RVA: 0x0000271D File Offset: 0x0000091D
	private void Update()
	{
	}
}
