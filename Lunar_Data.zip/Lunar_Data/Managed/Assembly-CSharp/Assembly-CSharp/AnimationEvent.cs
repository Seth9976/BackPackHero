﻿using System;
using UnityEngine;

// Token: 0x02000005 RID: 5
public class AnimationEvent : MonoBehaviour
{
	// Token: 0x06000014 RID: 20 RVA: 0x000024D0 File Offset: 0x000006D0
	public void Destroy()
	{
		Object.Destroy(base.gameObject);
	}
}
