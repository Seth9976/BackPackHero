﻿using System;
using UnityEngine;

// Token: 0x02000012 RID: 18
public class CardDescription : MonoBehaviour
{
	// Token: 0x04000044 RID: 68
	[SerializeField]
	public string cardName = "";

	// Token: 0x04000045 RID: 69
	[SerializeField]
	public string cardDescription = "";

	// Token: 0x04000046 RID: 70
	[SerializeField]
	public CardEffect cardEffect;
}
