﻿using System;
using UnityEngine;

// Token: 0x02000026 RID: 38
public class DeckInfo : MonoBehaviour
{
	// Token: 0x040000DA RID: 218
	[SerializeField]
	public string deckName;
}
