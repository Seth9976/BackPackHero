﻿using System;
using UnityEngine;

// Token: 0x02000009 RID: 9
public class Builder : MonoBehaviour
{
	// Token: 0x04000016 RID: 22
	private static string[] scenes = new string[] { "Assets/Scenes/Main Menu.unity", "Assets/Scenes/Game.unity" };
}
