﻿using System;

namespace Pathfinding
{
	// Token: 0x0200007A RID: 122
	public interface IOffMeshLinkStateMachine
	{
		// Token: 0x060003EF RID: 1007 RVA: 0x000033F6 File Offset: 0x000015F6
		void OnAbortTraversingOffMeshLink()
		{
		}
	}
}
