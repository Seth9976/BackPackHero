﻿using System;

namespace Pathfinding
{
	// Token: 0x0200003A RID: 58
	public enum GraphDebugMode
	{
		// Token: 0x04000182 RID: 386
		SolidColor,
		// Token: 0x04000183 RID: 387
		G,
		// Token: 0x04000184 RID: 388
		H,
		// Token: 0x04000185 RID: 389
		F,
		// Token: 0x04000186 RID: 390
		Penalty,
		// Token: 0x04000187 RID: 391
		Areas,
		// Token: 0x04000188 RID: 392
		Tags,
		// Token: 0x04000189 RID: 393
		HierarchicalNode,
		// Token: 0x0400018A RID: 394
		NavmeshBorderObstacles
	}
}
