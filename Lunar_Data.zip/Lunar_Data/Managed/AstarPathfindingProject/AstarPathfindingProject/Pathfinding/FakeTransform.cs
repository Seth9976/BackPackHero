﻿using System;
using UnityEngine;

namespace Pathfinding
{
	// Token: 0x0200001D RID: 29
	public struct FakeTransform
	{
		// Token: 0x04000102 RID: 258
		public Vector3 position;

		// Token: 0x04000103 RID: 259
		public Quaternion rotation;
	}
}
