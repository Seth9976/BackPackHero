﻿using System;

namespace Pathfinding.Serialization
{
	// Token: 0x02000234 RID: 564
	public class JsonOptInAttribute : Attribute
	{
	}
}
