﻿using System;

namespace Pathfinding.Serialization
{
	// Token: 0x02000233 RID: 563
	public class JsonMemberAttribute : Attribute
	{
	}
}
