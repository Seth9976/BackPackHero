﻿using System;

namespace Pathfinding.Serialization
{
	// Token: 0x02000235 RID: 565
	public class JsonDynamicTypeAttribute : Attribute
	{
	}
}
