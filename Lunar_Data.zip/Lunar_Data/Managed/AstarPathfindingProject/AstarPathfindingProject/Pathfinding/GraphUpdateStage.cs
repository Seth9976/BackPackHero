﻿using System;

namespace Pathfinding
{
	// Token: 0x0200002B RID: 43
	public enum GraphUpdateStage
	{
		// Token: 0x0400014A RID: 330
		Created,
		// Token: 0x0400014B RID: 331
		Pending,
		// Token: 0x0400014C RID: 332
		Applied,
		// Token: 0x0400014D RID: 333
		Aborted
	}
}
