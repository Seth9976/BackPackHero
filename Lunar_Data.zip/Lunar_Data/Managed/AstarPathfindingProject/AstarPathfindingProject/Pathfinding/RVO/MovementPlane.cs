﻿using System;

namespace Pathfinding.RVO
{
	// Token: 0x02000296 RID: 662
	public enum MovementPlane
	{
		// Token: 0x04000BBB RID: 3003
		XZ,
		// Token: 0x04000BBC RID: 3004
		XY,
		// Token: 0x04000BBD RID: 3005
		Arbitrary
	}
}
