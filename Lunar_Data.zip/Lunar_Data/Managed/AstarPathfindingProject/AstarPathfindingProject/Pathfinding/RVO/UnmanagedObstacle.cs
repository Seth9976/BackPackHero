﻿using System;

namespace Pathfinding.RVO
{
	// Token: 0x02000294 RID: 660
	public struct UnmanagedObstacle
	{
		// Token: 0x04000BB4 RID: 2996
		public int verticesAllocation;

		// Token: 0x04000BB5 RID: 2997
		public int groupsAllocation;
	}
}
