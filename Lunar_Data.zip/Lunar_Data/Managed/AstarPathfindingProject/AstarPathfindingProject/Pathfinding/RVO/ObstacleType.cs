﻿using System;

namespace Pathfinding.RVO
{
	// Token: 0x02000292 RID: 658
	public enum ObstacleType
	{
		// Token: 0x04000BAE RID: 2990
		Chain,
		// Token: 0x04000BAF RID: 2991
		Loop
	}
}
