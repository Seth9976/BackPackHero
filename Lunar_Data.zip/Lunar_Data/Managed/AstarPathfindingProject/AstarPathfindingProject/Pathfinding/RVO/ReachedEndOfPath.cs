﻿using System;

namespace Pathfinding.RVO
{
	// Token: 0x02000295 RID: 661
	public enum ReachedEndOfPath
	{
		// Token: 0x04000BB7 RID: 2999
		NotReached,
		// Token: 0x04000BB8 RID: 3000
		ReachedSoon,
		// Token: 0x04000BB9 RID: 3001
		Reached
	}
}
