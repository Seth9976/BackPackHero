﻿using System;

namespace Pathfinding
{
	// Token: 0x0200003E RID: 62
	public enum CloseToDestinationMode
	{
		// Token: 0x040001A4 RID: 420
		Stop,
		// Token: 0x040001A5 RID: 421
		ContinueToExactDestination
	}
}
