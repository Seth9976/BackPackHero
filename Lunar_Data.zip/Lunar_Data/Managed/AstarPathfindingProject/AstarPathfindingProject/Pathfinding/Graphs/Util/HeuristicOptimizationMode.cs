﻿using System;

namespace Pathfinding.Graphs.Util
{
	// Token: 0x02000192 RID: 402
	public enum HeuristicOptimizationMode
	{
		// Token: 0x0400076A RID: 1898
		None,
		// Token: 0x0400076B RID: 1899
		Random,
		// Token: 0x0400076C RID: 1900
		RandomSpreadOut,
		// Token: 0x0400076D RID: 1901
		Custom
	}
}
