﻿using System;

namespace Pathfinding.Graphs.Navmesh.Voxelization.Burst
{
	// Token: 0x020001D6 RID: 470
	internal struct CellMinMax
	{
		// Token: 0x0400088C RID: 2188
		public int objectID;

		// Token: 0x0400088D RID: 2189
		public int min;

		// Token: 0x0400088E RID: 2190
		public int max;
	}
}
