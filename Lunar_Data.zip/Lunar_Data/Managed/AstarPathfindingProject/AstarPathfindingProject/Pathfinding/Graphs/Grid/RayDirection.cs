﻿using System;

namespace Pathfinding.Graphs.Grid
{
	// Token: 0x020001F8 RID: 504
	public enum RayDirection
	{
		// Token: 0x0400095D RID: 2397
		Up,
		// Token: 0x0400095E RID: 2398
		Down,
		// Token: 0x0400095F RID: 2399
		Both
	}
}
