﻿using System;

namespace Pathfinding.Graphs.Grid
{
	// Token: 0x020001F7 RID: 503
	public enum ColliderType
	{
		// Token: 0x04000959 RID: 2393
		Sphere,
		// Token: 0x0400095A RID: 2394
		Capsule,
		// Token: 0x0400095B RID: 2395
		Ray
	}
}
