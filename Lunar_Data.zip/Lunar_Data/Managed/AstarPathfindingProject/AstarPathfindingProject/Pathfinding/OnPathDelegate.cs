﻿using System;

namespace Pathfinding
{
	// Token: 0x02000034 RID: 52
	// (Invoke) Token: 0x0600021E RID: 542
	public delegate void OnPathDelegate(Path p);
}
