﻿using System;

namespace Pathfinding
{
	// Token: 0x02000036 RID: 54
	// (Invoke) Token: 0x06000226 RID: 550
	public delegate void OnScanDelegate(AstarPath script);
}
