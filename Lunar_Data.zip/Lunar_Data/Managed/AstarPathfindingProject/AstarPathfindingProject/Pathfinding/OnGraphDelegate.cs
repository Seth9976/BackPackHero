﻿using System;

namespace Pathfinding
{
	// Token: 0x02000035 RID: 53
	// (Invoke) Token: 0x06000222 RID: 546
	public delegate void OnGraphDelegate(NavGraph graph);
}
