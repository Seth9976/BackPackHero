﻿using System;

namespace Pathfinding
{
	// Token: 0x020000C6 RID: 198
	public struct GridHitInfo
	{
		// Token: 0x04000450 RID: 1104
		public GridNodeBase node;

		// Token: 0x04000451 RID: 1105
		public int direction;
	}
}
