﻿using System;

namespace Pathfinding
{
	// Token: 0x02000040 RID: 64
	public enum InspectorGridHexagonNodeSize
	{
		// Token: 0x040001AB RID: 427
		Width,
		// Token: 0x040001AC RID: 428
		Diameter,
		// Token: 0x040001AD RID: 429
		NodeSize
	}
}
