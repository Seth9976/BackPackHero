﻿using System;
using Pathfinding.Util;

namespace Pathfinding
{
	// Token: 0x0200002F RID: 47
	public interface ITransformedGraph
	{
		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060001F3 RID: 499
		GraphTransform transform { get; }
	}
}
