﻿using System;

namespace Pathfinding
{
	// Token: 0x02000039 RID: 57
	public enum Heuristic
	{
		// Token: 0x0400017D RID: 381
		Manhattan,
		// Token: 0x0400017E RID: 382
		DiagonalManhattan,
		// Token: 0x0400017F RID: 383
		Euclidean,
		// Token: 0x04000180 RID: 384
		None
	}
}
