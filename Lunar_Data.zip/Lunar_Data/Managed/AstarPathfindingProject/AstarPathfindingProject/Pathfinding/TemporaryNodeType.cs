﻿using System;

namespace Pathfinding
{
	// Token: 0x020000AE RID: 174
	public enum TemporaryNodeType
	{
		// Token: 0x040003A5 RID: 933
		Start,
		// Token: 0x040003A6 RID: 934
		End,
		// Token: 0x040003A7 RID: 935
		Ignore
	}
}
