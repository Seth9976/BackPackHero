﻿using System;

namespace Pathfinding
{
	// Token: 0x02000041 RID: 65
	public enum InspectorGridMode
	{
		// Token: 0x040001AF RID: 431
		Grid,
		// Token: 0x040001B0 RID: 432
		IsometricGrid,
		// Token: 0x040001B1 RID: 433
		Hexagonal,
		// Token: 0x040001B2 RID: 434
		Advanced
	}
}
