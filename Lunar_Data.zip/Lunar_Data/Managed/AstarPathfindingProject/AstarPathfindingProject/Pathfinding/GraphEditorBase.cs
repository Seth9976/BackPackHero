﻿using System;
using Pathfinding.Serialization;

namespace Pathfinding
{
	// Token: 0x02000068 RID: 104
	[JsonOptIn]
	public class GraphEditorBase
	{
		// Token: 0x0400025F RID: 607
		public NavGraph target;
	}
}
