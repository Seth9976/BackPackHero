﻿using System;

namespace Pathfinding
{
	// Token: 0x02000165 RID: 357
	[Obsolete("This class has been renamed to ProceduralGraphMover", true)]
	public class ProceduralGridMover
	{
	}
}
