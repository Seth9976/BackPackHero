﻿using System;

namespace Pathfinding
{
	// Token: 0x0200003B RID: 59
	public enum ThreadCount
	{
		// Token: 0x0400018C RID: 396
		AutomaticLowLoad = -1,
		// Token: 0x0400018D RID: 397
		AutomaticHighLoad = -2,
		// Token: 0x0400018E RID: 398
		None = 0,
		// Token: 0x0400018F RID: 399
		One,
		// Token: 0x04000190 RID: 400
		Two,
		// Token: 0x04000191 RID: 401
		Three,
		// Token: 0x04000192 RID: 402
		Four,
		// Token: 0x04000193 RID: 403
		Five,
		// Token: 0x04000194 RID: 404
		Six,
		// Token: 0x04000195 RID: 405
		Seven,
		// Token: 0x04000196 RID: 406
		Eight
	}
}
