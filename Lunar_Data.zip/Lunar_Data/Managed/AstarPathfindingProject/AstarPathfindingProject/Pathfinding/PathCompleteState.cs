﻿using System;

namespace Pathfinding
{
	// Token: 0x0200003D RID: 61
	public enum PathCompleteState
	{
		// Token: 0x0400019F RID: 415
		NotCalculated,
		// Token: 0x040001A0 RID: 416
		Error,
		// Token: 0x040001A1 RID: 417
		Complete,
		// Token: 0x040001A2 RID: 418
		Partial
	}
}
