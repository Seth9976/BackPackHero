﻿using System;

namespace Pathfinding
{
	// Token: 0x0200003F RID: 63
	public enum Side : byte
	{
		// Token: 0x040001A7 RID: 423
		Colinear,
		// Token: 0x040001A8 RID: 424
		Left,
		// Token: 0x040001A9 RID: 425
		Right
	}
}
