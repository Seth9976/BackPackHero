﻿using System;

namespace Pathfinding
{
	// Token: 0x020000C5 RID: 197
	public enum NumNeighbours
	{
		// Token: 0x0400044D RID: 1101
		Four,
		// Token: 0x0400044E RID: 1102
		Eight,
		// Token: 0x0400044F RID: 1103
		Six
	}
}
