﻿using System;

namespace Pathfinding
{
	// Token: 0x02000038 RID: 56
	public enum PathLog
	{
		// Token: 0x04000177 RID: 375
		None,
		// Token: 0x04000178 RID: 376
		Normal,
		// Token: 0x04000179 RID: 377
		Heavy,
		// Token: 0x0400017A RID: 378
		InGame,
		// Token: 0x0400017B RID: 379
		OnlyErrors
	}
}
