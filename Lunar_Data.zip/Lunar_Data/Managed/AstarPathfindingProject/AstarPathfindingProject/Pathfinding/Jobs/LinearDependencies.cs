﻿using System;

namespace Pathfinding.Jobs
{
	// Token: 0x0200017E RID: 382
	internal enum LinearDependencies : byte
	{
		// Token: 0x04000738 RID: 1848
		Check,
		// Token: 0x04000739 RID: 1849
		Enabled,
		// Token: 0x0400073A RID: 1850
		Disabled
	}
}
