﻿using System;

namespace Pathfinding.Jobs
{
	// Token: 0x02000179 RID: 377
	internal class DisableUninitializedReadCheckAttribute : Attribute
	{
	}
}
