﻿using System;

namespace Pathfinding.Jobs
{
	// Token: 0x0200017A RID: 378
	public interface IArenaDisposable
	{
		// Token: 0x06000A8E RID: 2702
		void DisposeWith(DisposeArena arena);
	}
}
