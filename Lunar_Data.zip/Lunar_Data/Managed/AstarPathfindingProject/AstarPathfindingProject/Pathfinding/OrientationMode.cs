﻿using System;

namespace Pathfinding
{
	// Token: 0x02000042 RID: 66
	public enum OrientationMode : byte
	{
		// Token: 0x040001B4 RID: 436
		ZAxisForward,
		// Token: 0x040001B5 RID: 437
		YAxisForward
	}
}
