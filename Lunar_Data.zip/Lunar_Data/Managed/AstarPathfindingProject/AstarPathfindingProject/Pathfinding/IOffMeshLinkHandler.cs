﻿using System;

namespace Pathfinding
{
	// Token: 0x02000079 RID: 121
	public interface IOffMeshLinkHandler
	{
		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060003EE RID: 1006 RVA: 0x000146B9 File Offset: 0x000128B9
		string name
		{
			get
			{
				return null;
			}
		}
	}
}
