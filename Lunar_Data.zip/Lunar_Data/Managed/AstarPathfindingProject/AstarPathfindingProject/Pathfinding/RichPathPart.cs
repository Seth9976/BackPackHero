﻿using System;
using Pathfinding.Util;

namespace Pathfinding
{
	// Token: 0x0200001B RID: 27
	public abstract class RichPathPart : IAstarPooledObject
	{
		// Token: 0x06000195 RID: 405
		public abstract void OnEnterPool();
	}
}
